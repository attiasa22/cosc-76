### PA3 - ReadMe
#### COSC 76
##### Ariel Attias



Installation: Unzip the files into your preferred location on your computer.
 
 Execution: Run `python3 PATH/TO/test_chess.py` to generate the chess game with two players, either human or robotic.
 To experiment with other games
 1. Create a new `player` instance. (e.g. `player4 = AlphaBetaAI(depth = 4)`)
 2. Pass these players into a new chess game, as 'game = ChessGame(player1, player5)'
 3. Run the program to play
